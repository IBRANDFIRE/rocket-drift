#!/usr/bin/env python3
"""
parse_project.py
-----------------
Converts a Catrobat / Pocket Code project file (.catrobat / .newtrobat, a zip
containing code.xml plus scene image/sound folders) into:

  assets/project/project.json   <- flattened, reference-resolved scene graph
  assets/project/media/...      <- copied images & sounds, renamed to safe ids

Usage:
    python3 parse_project.py path/to/project.catrobat app/src/main/assets/project

The output JSON is consumed by runtime.js in the WebView shell.

Why this is needed:
Catrobat's code.xml is produced by an XStream-style Java serializer. Repeated
object references (most commonly <userVariable reference="../../../.."/> and
<userList reference="..."/>) are NOT inlined -- they're relative XPath-like
paths to the *first* place that object was fully written out. A naive XML->
dict conversion leaves these as dangling pointers, so this script resolves
every `reference` attribute to the real element before flattening anything
else. Formula trees (leftChild/rightChild/type/value) are converted into a
compact nested dict the JS evaluator can walk directly.
"""

import sys
import os
import re
import json
import shutil
import zipfile
import tempfile
from lxml import etree


# ---------------------------------------------------------------------------
# 1. Reference resolution (XStream relative-path pointers)
# ---------------------------------------------------------------------------

def resolve_reference(elem, ref_path, root):
    """
    Resolve a Catrobat `reference="../../../../script[11]/brickList/brick[4]/userVariable"`
    attribute relative to `elem`'s position in the tree.

    Algorithm: walk up one parent per leading `../` segment, then descend
    child-by-tag[index] for the remaining segments (1-based indices, as
    XStream emits them; a bare tag with no index means index 1).
    """
    node = elem
    segments = ref_path.split('/')
    i = 0
    while i < len(segments) and segments[i] == '..':
        node = node.getparent()
        if node is None:
            return None
        i += 1
    for seg in segments[i:]:
        if seg == '':
            continue
        m = re.match(r'^([A-Za-z0-9_]+)(?:\[(\d+)\])?$', seg)
        if not m:
            return None
        tag, idx = m.group(1), int(m.group(2) or 1)
        matches = [c for c in node.iterchildren(tag=tag)]
        if idx > len(matches) or idx < 1:
            return None
        node = matches[idx - 1]
    return node


def resolve_all_references(root, max_passes=6):
    """
    Repeatedly find elements with a `reference` attribute and splice in a
    deep copy of the element they point to (references can themselves point
    at nodes that were, at the time of writing, also references-once-removed
    in pathological files, hence multiple passes).
    """
    for _ in range(max_passes):
        refs = root.xpath('//*[@reference]')
        if not refs:
            break
        progress = False
        for elem in refs:
            ref_path = elem.get('reference')
            target = resolve_reference(elem, ref_path, root)
            if target is None:
                continue
            new_elem = etree.fromstring(etree.tostring(target))
            new_elem.tag = elem.tag
            if 'reference' in new_elem.attrib:
                del new_elem.attrib['reference']
            parent = elem.getparent()
            parent.replace(elem, new_elem)
            progress = True
        if not progress:
            break
    return root


# ---------------------------------------------------------------------------
# 2. Formula tree -> compact nested dict
# ---------------------------------------------------------------------------

def parse_formula(elem):
    if elem is None:
        return None
    node = {
        'type': _text(elem.find('type')),
        'value': _text(elem.find('value')),
    }
    left = elem.find('leftChild')
    right = elem.find('rightChild')
    if left is not None and len(left):
        node['left'] = parse_formula(left)
    if right is not None and len(right):
        node['right'] = parse_formula(right)
    extra = elem.find('additionalChildren')
    if extra is not None and len(extra):
        node['extra'] = [parse_formula(c) for c in extra]
    return node


def _text(elem):
    if elem is None or elem.text is None:
        return ''
    return elem.text


# ---------------------------------------------------------------------------
# 3. Bricks / scripts
# ---------------------------------------------------------------------------

SIMPLE_VALUE_TAGS = {
    # child tags of a brick that are plain values, not formulas/sub-structures
}

def parse_brick(elem):
    brick = {'type': elem.get('type') or elem.tag}
    fl = elem.find('formulaList')
    if fl is not None:
        formulas = {}
        for f in fl.findall('formula'):
            cat = f.get('category', 'DEFAULT')
            formulas[cat] = parse_formula(f)
        brick['formulas'] = formulas

    look = elem.find('look')
    if look is not None:
        name_el = look.find('name')
        if name_el is not None:
            brick['look'] = _text(name_el)

    sound = elem.find('sound')
    if sound is not None:
        name_el = sound.find('name')
        if name_el is not None:
            brick['sound'] = _text(name_el)

    uv = elem.find('userVariable')
    if uv is not None:
        name_el = uv.find('.//name')
        brick['variable'] = _text(name_el) if name_el is not None else None

    ul = elem.find('userList')
    if ul is None:
        ul = elem.find('userDataList')  # ForItemInUserListBrick names it differently
    if ul is not None:
        name_el = ul.find('.//name')
        brick['list'] = _text(name_el) if name_el is not None else None

    for tag in ('broadcastMessage', 'sceneToStart', 'sceneForTransition',
                'spinnerSelection', 'selection', 'type', 'alignmentSelection'):
        e = elem.find(tag)
        if e is not None:
            brick[tag] = _text(e)

    # Nested bodies: if/if-then use ifBranchBricks + elseBranchBricks,
    # loops (Forever/Repeat/RepeatUntil/ForVariableFromTo/ForItemInUserList) use loopBricks.
    if_body = elem.find('ifBranchBricks')
    if if_body is not None:
        brick['bricks'] = [parse_brick(b) for b in if_body.findall('brick')]
    else_body = elem.find('elseBranchBricks')
    if else_body is not None:
        brick['elseBricks'] = [parse_brick(b) for b in else_body.findall('brick')]
    loop_body = elem.find('loopBricks')
    if loop_body is not None:
        brick['bricks'] = [parse_brick(b) for b in loop_body.findall('brick')]

    return brick


def parse_script(elem):
    script = {
        'type': elem.get('type'),
        'bricks': [parse_brick(b) for b in elem.find('brickList').findall('brick')]
                   if elem.find('brickList') is not None else [],
    }
    rm = elem.find('receivedMessage')
    if rm is not None:
        script['receivedMessage'] = _text(rm)
    return script


def parse_user_data(container_elem, tag):
    out = []
    if container_elem is None:
        return out
    for e in container_elem.findall(tag):
        name_el = e.find('.//name')
        out.append({'name': _text(name_el) if name_el is not None else ''})
    return out


def parse_object(elem):
    looks = []
    ll = elem.find('lookList')
    if ll is not None:
        for l in ll.findall('look'):
            looks.append({'name': l.get('name'), 'fileName': l.get('fileName')})

    sounds = []
    sl = elem.find('soundList')
    if sl is not None:
        for s in sl.findall('sound'):
            sounds.append({'name': s.get('name'), 'fileName': s.get('fileName')})

    scripts = []
    scl = elem.find('scriptList')
    if scl is not None:
        for s in scl.findall('script'):
            scripts.append(parse_script(s))

    return {
        'name': elem.get('name'),
        'type': elem.get('type'),
        'looks': looks,
        'sounds': sounds,
        'scripts': scripts,
        'variables': parse_user_data(elem.find('userVariables'), 'userVariable'),
        'lists': parse_user_data(elem.find('userLists'), 'userList'),
    }


def parse_scene(elem):
    objects = []
    ol = elem.find('objectList')
    if ol is not None:
        for o in ol.findall('object'):
            objects.append(parse_object(o))
    return {
        'name': _text(elem.find('name')),
        'objects': objects,
    }


# ---------------------------------------------------------------------------
# 4. Top level
# ---------------------------------------------------------------------------

def safe_id(name, used):
    base = re.sub(r'[^A-Za-z0-9_.-]+', '_', name).strip('_') or 'file'
    candidate = base
    n = 1
    while candidate in used:
        n += 1
        candidate = f'{base}_{n}'
    used.add(candidate)
    return candidate


def convert(project_path, out_dir):
    tmp = tempfile.mkdtemp(prefix='catrobat_')
    with zipfile.ZipFile(project_path) as z:
        z.extractall(tmp)

    code_xml = os.path.join(tmp, 'code.xml')
    if not os.path.exists(code_xml):
        # some exports nest it one folder down
        for root_dir, _dirs, files in os.walk(tmp):
            if 'code.xml' in files:
                code_xml = os.path.join(root_dir, 'code.xml')
                break

    parser = etree.XMLParser(remove_blank_text=False, huge_tree=True)
    tree = etree.parse(code_xml, parser)
    root = tree.getroot()
    resolve_all_references(root)

    header_el = root.find('header')
    header = {}
    if header_el is not None:
        for child in header_el:
            header[child.tag] = _text(child)

    scenes_el = root.find('scenes')
    scenes = [parse_scene(s) for s in scenes_el.findall('scene')] if scenes_el is not None else []

    global_vars = parse_user_data(root.find('programVariableList'), 'userVariable')
    global_lists = parse_user_data(root.find('programListOfLists'), 'userList')

    media_out = os.path.join(out_dir, 'media')
    os.makedirs(media_out, exist_ok=True)
    used_names = set()
    file_map = {}  # original relative path fragments (by filename) -> safe media id

    project_root = os.path.dirname(code_xml)
    for root_dir, _dirs, files in os.walk(project_root):
        for fname in files:
            if fname in ('code.xml', '.nomedia') or fname.startswith('.'):
                continue
            if fname in file_map:
                continue
            src = os.path.join(root_dir, fname)
            sid = safe_id(fname, used_names)
            shutil.copyfile(src, os.path.join(media_out, sid))
            file_map[fname] = sid

    def remap_media(scenes):
        for scene in scenes:
            for obj in scene['objects']:
                for look in obj['looks']:
                    look['file'] = file_map.get(look['fileName'], '')
                for sound in obj['sounds']:
                    sound['file'] = file_map.get(sound['fileName'], '')
        return scenes

    scenes = remap_media(scenes)

    project = {
        'header': {
            'programName': header.get('programName', 'Untitled'),
            'screenWidth': int(float(header.get('screenWidth') or 480)),
            'screenHeight': int(float(header.get('screenHeight') or 800)),
            'screenMode': header.get('screenMode', 'STRETCH'),
            'landscapeMode': header.get('landscapeMode', 'false') == 'true',
        },
        'scenes': scenes,
        'globals': {'variables': global_vars, 'lists': global_lists},
    }

    with open(os.path.join(out_dir, 'project.json'), 'w', encoding='utf-8') as f:
        json.dump(project, f, ensure_ascii=False, separators=(',', ':'))

    shutil.rmtree(tmp, ignore_errors=True)
    print(f"Wrote {out_dir}/project.json  ({len(scenes)} scene(s), "
          f"{sum(len(s['objects']) for s in scenes)} object(s), "
          f"{len(used_names)} media file(s))")


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print(__doc__)
        print("Usage: python3 parse_project.py <project.catrobat> <output_assets_dir>")
        sys.exit(1)
    convert(sys.argv[1], sys.argv[2])
