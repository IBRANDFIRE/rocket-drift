/* runtime.js — NEWCATROID generic engine
 * Interprets assets/project/project.json (produced by tools/parse_project.py)
 * and runs it on a <canvas>. Scripts are compiled into JS generator functions;
 * one "yield" == one scheduler tick, so Wait/RepeatUntil/loops never freeze
 * the page and everything can be paused/stepped uniformly.
 *
 * Coverage: this implements the full brick catalog Catrobat ships as of the
 * 1.x language version this template targets. A few device-integration
 * bricks are intentionally simplified (see README "Known limitations") —
 * they degrade gracefully (no-op + console.warn) instead of throwing.
 */
(function () {
'use strict';

// ---------------------------------------------------------------------
// Formula evaluator
// ---------------------------------------------------------------------
const Formula = {
  evaluate(node, ctx) {
    if (!node) return 0;
    switch (node.type) {
      case 'NUMBER': return parseFloat(node.value) || 0;
      case 'STRING': return node.value ?? '';
      case 'OPERATOR': return Formula.op(node, ctx);
      case 'FUNCTION': return Formula.fn(node, ctx);
      case 'SENSOR': return Formula.sensor(node.value, ctx);
      case 'USER_VARIABLE': return ctx.engine.getVariable(ctx.sprite, node.value);
      case 'USER_LIST': return ctx.engine.getList(ctx.sprite, node.value).join(' ');
      case 'COLLISION_FORMULA': return ctx.engine.isCollidingWithName(ctx.sprite, node.value) ? 1 : 0;
      default: return 0;
    }
  },

  num(node, ctx) { return Formula.toNumber(Formula.evaluate(node, ctx)); },
  toNumber(v) { const n = parseFloat(v); return isNaN(n) ? 0 : n; },
  toBool(v) {
    if (typeof v === 'boolean') return v;
    if (typeof v === 'number') return v !== 0;
    const s = String(v).trim().toLowerCase();
    if (s === '') return false;
    if (s === 'false' || s === '0') return false;
    return true;
  },

  op(node, ctx) {
    const L = () => Formula.evaluate(node.left, ctx);
    const R = () => Formula.evaluate(node.right, ctx);
    const Ln = () => Formula.num(node.left, ctx);
    const Rn = () => Formula.num(node.right, ctx);
    switch (node.value) {
      case 'PLUS': return Ln() + Rn();
      case 'MINUS': return Ln() - Rn();
      case 'MULT': return Ln() * Rn();
      case 'DIVIDE': { const d = Rn(); return d === 0 ? 0 : Ln() / d; }
      case 'EQUAL': return looseEq(L(), R()) ? 1 : 0;
      case 'NOT_EQUAL': return !looseEq(L(), R()) ? 1 : 0;
      case 'GREATER_THAN': return Ln() > Rn() ? 1 : 0;
      case 'GREATER_OR_EQUAL': return Ln() >= Rn() ? 1 : 0;
      case 'SMALLER_THAN': return Ln() < Rn() ? 1 : 0;
      case 'SMALLER_OR_EQUAL': return Ln() <= Rn() ? 1 : 0;
      case 'LOGICAL_AND': return (Formula.toBool(L()) && Formula.toBool(R())) ? 1 : 0;
      case 'LOGICAL_OR': return (Formula.toBool(L()) || Formula.toBool(R())) ? 1 : 0;
      case 'LOGICAL_NOT': return !Formula.toBool(R()) ? 1 : 0;
      default: return 0;
    }
    function looseEq(a, b) {
      if (typeof a === 'number' || typeof b === 'number') {
        const na = Formula.toNumber(a), nb = Formula.toNumber(b);
        if (!isNaN(na) && !isNaN(nb) && (String(a).trim() !== '' && String(b).trim() !== '')) return na === nb;
      }
      return String(a) === String(b);
    }
  },

  fn(node, ctx) {
    const n = (c) => Formula.num(c, ctx);
    const s = (c) => String(Formula.evaluate(c, ctx));
    const extra = (node.extra || []).map(e => Formula.evaluate(e, ctx));
    switch (node.value) {
      case 'TRUE': return 1;
      case 'FALSE': return 0;
      case 'SIN': return Math.sin(deg2rad(n(node.left)));
      case 'COS': return Math.cos(deg2rad(n(node.left)));
      case 'TAN': return Math.tan(deg2rad(n(node.left)));
      case 'ARCSIN': return rad2deg(Math.asin(n(node.left)));
      case 'ARCCOS': return rad2deg(Math.acos(n(node.left)));
      case 'ARCTAN': return rad2deg(Math.atan(n(node.left)));
      case 'ARCTAN2': return rad2deg(Math.atan2(n(node.left), n(node.right)));
      case 'LN': return Math.log(n(node.left));
      case 'LOG': return Math.log10(n(node.left));
      case 'PI': return Math.PI;
      case 'SQRT': return Math.sqrt(n(node.left));
      case 'RAND': { const a = n(node.left), b = n(node.right); const lo = Math.min(a,b), hi = Math.max(a,b); return lo + Math.random() * (hi - lo); }
      case 'ABS': return Math.abs(n(node.left));
      case 'ROUND': return Math.round(n(node.left));
      case 'MOD': { const b = n(node.right); return b === 0 ? 0 : n(node.left) % b; }
      case 'EXP': return Math.exp(n(node.left));
      case 'POWER': return Math.pow(n(node.left), n(node.right));
      case 'FLOOR': return Math.floor(n(node.left));
      case 'CEIL': return Math.ceil(n(node.left));
      case 'MAX': return Math.max(n(node.left), n(node.right));
      case 'MIN': return Math.min(n(node.left), n(node.right));
      case 'IF_THEN_ELSE': return Formula.toBool(Formula.evaluate(node.left, ctx)) ? Formula.evaluate(node.right, ctx) : (extra[0] ?? '');
      case 'LENGTH': return s(node.left).length;
      case 'LETTER': { const i = Math.round(n(node.left)); const str = s(node.right); return (i >= 1 && i <= str.length) ? str[i - 1] : ''; }
      case 'SUBTEXT': { const from = Math.round(n(node.left)); const to = Math.round(n(node.right)); const str = extra[0] !== undefined ? String(extra[0]) : ''; return str.slice(Math.max(0, from - 1), Math.max(0, to)); }
      case 'JOIN': return s(node.left) + s(node.right);
      case 'JOIN3': return s(node.left) + s(node.right) + (extra[0] !== undefined ? String(extra[0]) : '');
      case 'REGEX': { try { return (new RegExp(s(node.left))).exec(s(node.right))?.[0] ?? ''; } catch (e) { return ''; } }
      case 'NUMBER_OF_ITEMS': return ctx.engine.getList(ctx.sprite, node.left.value).length;
      case 'LIST_ITEM': { const i = Math.round(n(node.left)); const list = ctx.engine.getList(ctx.sprite, node.right.value); return (i >= 1 && i <= list.length) ? list[i - 1] : ''; }
      case 'CONTAINS': { const list = ctx.engine.getList(ctx.sprite, node.left.value); const needle = s(node.right); return list.some(v => String(v) === needle) ? 1 : 0; }
      case 'INDEX_OF_ITEM': { const needle = s(node.left); const list = ctx.engine.getList(ctx.sprite, node.right.value); const i = list.findIndex(v => String(v) === needle); return i + 1; }
      case 'FLATTEN': return ctx.engine.getList(ctx.sprite, node.left.value).join(' ');
      case 'COLOR_TOUCHES_COLOR':
      case 'COLLIDES_WITH_COLOR':
        return 0; // per-pixel colour detection is out of scope for this template
      default:
        console.warn('[formula] unimplemented FUNCTION', node.value);
        return 0;
    }
  },

  sensor(name, ctx) {
    const sp = ctx.sprite;
    switch (name) {
      case 'OBJECT_X': return sp.x;
      case 'OBJECT_Y': return sp.y;
      case 'OBJECT_X_VELOCITY': return sp.velocityX || 0;
      case 'OBJECT_Y_VELOCITY': return sp.velocityY || 0;
      case 'OBJECT_ANGULAR_VELOCITY': return sp.angularVelocity || 0;
      case 'LOOK_DIRECTION':
      case 'MOTION_DIRECTION': return sp.direction;
      case 'OBJECT_TRANSPARENCY': return sp.transparency;
      case 'OBJECT_BRIGHTNESS': return sp.brightness;
      case 'OBJECT_COLOR': return sp.colorFilter || '#000000';
      case 'OBJECT_LOOK_NUMBER': return sp.lookIndex + 1;
      case 'OBJECT_LOOK_NAME': return (sp.looks[sp.lookIndex] || {}).name || '';
      case 'OBJECT_SIZE': return sp.size;
      case 'OBJECT_LAYER': return sp.layer;
      case 'COLLIDES_WITH_EDGE': return ctx.engine.isOnEdge(sp) ? 1 : 0;
      case 'COLLIDES_WITH_FINGER': return ctx.engine.pointerDown && ctx.engine.pointInSprite(sp, ctx.engine.pointerStage) ? 1 : 0;
      default:
        console.warn('[formula] unimplemented SENSOR', name);
        return 0;
    }
  },
};
function deg2rad(d) { return d * Math.PI / 180; }
function rad2deg(r) { return r * 180 / Math.PI; }

// ---------------------------------------------------------------------
// Engine
// ---------------------------------------------------------------------
class Engine {
  constructor(canvas, project, mediaBase) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.project = project;
    this.mediaBase = mediaBase;
    this.stageW = project.header.screenWidth;
    this.stageH = project.header.screenHeight;
    this.globals = {}; // variable name -> value (program-wide)
    this.globalLists = {}; // list name -> array
    for (const v of project.globals.variables) this.globals[v.name] = 0;
    for (const l of project.globals.lists) this.globalLists[l.name] = [];

    this.images = new Map(); // media file -> HTMLImageElement
    this.audio = new Map();  // media file -> HTMLAudioElement (template, cloned per play)
    this.threads = [];       // running generator "threads"
    this.pointerDown = false;
    this.pointerStage = { x: 0, y: 0 };
    this.penLayer = document.createElement('canvas');
    this.penLayer.width = this.stageW;
    this.penLayer.height = this.stageH;
    this.penCtx = this.penLayer.getContext('2d');

    this._bindInput();
    this._resize();
    window.addEventListener('resize', () => this._resize());
  }

  // --- asset loading -----------------------------------------------
  async preload(scene) {
    const files = new Set();
    for (const obj of scene.objects) {
      for (const l of obj.looks) if (l.file) files.add(l.file);
      for (const s of obj.sounds) if (s.file) files.add(s.file);
    }
    await Promise.all([...files].map(f => this._loadMedia(f)));
  }

  _loadMedia(file) {
    const ext = file.split('.').pop().toLowerCase();
    const isImg = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'].includes(ext);
    if (isImg) {
      if (this.images.has(file)) return Promise.resolve();
      return new Promise((resolve) => {
        const img = new Image();
        img.onload = () => resolve();
        img.onerror = () => { console.warn('[media] failed to load', file); resolve(); };
        img.src = this.mediaBase + encodeURIComponent(file);
        this.images.set(file, img);
      });
    } else {
      const audio = new Audio(this.mediaBase + encodeURIComponent(file));
      this.audio.set(file, audio);
      return Promise.resolve();
    }
  }

  // --- scene / sprite setup -----------------------------------------
  async loadScene(sceneName) {
    this.threads = [];
    const scene = this.project.scenes.find(s => s.name === sceneName) || this.project.scenes[0];
    this.currentScene = scene;
    await this.preload(scene);
    this.sprites = scene.objects.map((o, i) => this._makeSprite(o, i));
    this.clones = [];
    this.penCtx.clearRect(0, 0, this.stageW, this.stageH);
    for (const sp of this.sprites) this._startScriptsOfType(sp, ['StartScript', 'SceneStartScript', 'WhenScript']);
    if (!this._looping) { this._looping = true; requestAnimationFrame(this._tick.bind(this)); }
  }

  _makeSprite(obj, layer) {
    return {
      name: obj.name, def: obj, layer,
      x: 0, y: 0, direction: 0, size: 100, transparency: 0, brightness: 100,
      colorFilter: null, visible: true, lookIndex: 0, rotationStyle: 'normal',
      looks: obj.looks, sounds: obj.sounds,
      variables: Object.fromEntries(obj.variables.map(v => [v.name, 0])),
      lists: Object.fromEntries(obj.lists.map(l => [l.name, []])),
      penDown: false, penColor: '#000000', penSize: 1,
      physicsType: 'NONE', velocityX: 0, velocityY: 0, angularVelocity: 0,
      mass: 1, bounce: 0.8, friction: 0.2, gravityX: 0, gravityY: -200,
      isClone: false, text: null,
    };
  }

  // --- variable / list access (object-local shadows global) ---------
  getVariable(sprite, name) {
    if (sprite && Object.prototype.hasOwnProperty.call(sprite.variables, name)) return sprite.variables[name];
    return this.globals[name] ?? 0;
  }
  setVariable(sprite, name, value) {
    if (sprite && Object.prototype.hasOwnProperty.call(sprite.variables, name)) sprite.variables[name] = value;
    else this.globals[name] = value;
  }
  getList(sprite, name) {
    if (sprite && Object.prototype.hasOwnProperty.call(sprite.lists, name)) return sprite.lists[name];
    if (!this.globalLists[name]) this.globalLists[name] = [];
    return this.globalLists[name];
  }

  // --- collisions / geometry -----------------------------------------
  spriteBounds(sp) {
    const img = this._currentImage(sp);
    const w = (img ? img.naturalWidth : 60) * sp.size / 100;
    const h = (img ? img.naturalHeight : 60) * sp.size / 100;
    return { left: sp.x - w / 2, right: sp.x + w / 2, bottom: sp.y - h / 2, top: sp.y + h / 2, w, h };
  }
  _currentImage(sp) {
    const look = sp.looks[sp.lookIndex];
    return look ? this.images.get(look.file) : null;
  }
  isCollidingWithName(sprite, otherName) {
    const all = [...(this.sprites || []), ...(this.clones || [])];
    const target = all.find(s => s.name === otherName && s !== sprite);
    if (!target || !sprite.visible || !target.visible) return false;
    const a = this.spriteBounds(sprite), b = this.spriteBounds(target);
    return a.left < b.right && a.right > b.left && a.bottom < b.top && a.top > b.bottom;
  }
  isOnEdge(sp) {
    const b = this.spriteBounds(sp);
    const halfW = this.stageW / 2, halfH = this.stageH / 2;
    return b.left <= -halfW || b.right >= halfW || b.bottom <= -halfH || b.top >= halfH;
  }
  pointInSprite(sp, stagePt) {
    const b = this.spriteBounds(sp);
    return stagePt.x >= b.left && stagePt.x <= b.right && stagePt.y >= b.bottom && stagePt.y <= b.top;
  }

  // --- broadcast / threads --------------------------------------------
  broadcast(message) {
    const started = [];
    for (const sp of [...this.sprites, ...this.clones]) {
      for (const script of sp.def.scripts) {
        if (script.type !== 'BroadcastScript') continue;
        if (script.receivedMessage !== message) continue;
        started.push(this._startThread(sp, script));
      }
    }
    return started;
  }

  _startThread(sp, script) {
    const thread = this._runScript(sp, script);
    thread.owner = sp;
    this.threads.push(thread);
    return thread;
  }
  _startScriptsOfType(sp, types) {
    for (const script of sp.def.scripts) {
      if (types.includes(script.type)) this._startThread(sp, script);
    }
  }
  _startTouchScripts(sp) {
    for (const script of sp.def.scripts) {
      if (script.type === 'WhenTouchDownScript') this._startThread(sp, script);
    }
  }

  // --- input -----------------------------------------------------------
  _bindInput() {
    const toStage = (evt) => {
      const rect = this.canvas.getBoundingClientRect();
      const px = (evt.touches ? evt.touches[0].clientX : evt.clientX) - rect.left;
      const py = (evt.touches ? evt.touches[0].clientY : evt.clientY) - rect.top;
      const sx = px * (this.stageW / rect.width) - this.stageW / 2;
      const sy = this.stageH / 2 - py * (this.stageH / rect.height);
      return { x: sx, y: sy };
    };
    const down = (evt) => {
      this.pointerDown = true;
      this.pointerStage = toStage(evt);
      for (const sp of (this.sprites || [])) {
        if (sp.visible && this.pointInSprite(sp, this.pointerStage)) this._startTouchScripts(sp);
      }
    };
    const move = (evt) => { if (this.pointerDown) this.pointerStage = toStage(evt); };
    const up = () => { this.pointerDown = false; };
    this.canvas.addEventListener('mousedown', down);
    this.canvas.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    this.canvas.addEventListener('touchstart', (e) => { down(e); }, { passive: true });
    this.canvas.addEventListener('touchmove', (e) => { move(e); }, { passive: true });
    window.addEventListener('touchend', up);
  }
  _resize() {
    const parent = this.canvas.parentElement;
    const scale = Math.min(parent.clientWidth / this.stageW, parent.clientHeight / this.stageH);
    this.canvas.style.width = (this.stageW * scale) + 'px';
    this.canvas.style.height = (this.stageH * scale) + 'px';
    this.canvas.width = this.stageW;
    this.canvas.height = this.stageH;
  }

  // --- main loop ---------------------------------------------------------
  _tick(now) {
    const dt = Math.min(0.05, ((now - (this._lastT || now)) / 1000));
    this._lastT = now;
    this._physicsStep(dt);
    for (let i = this.threads.length - 1; i >= 0; i--) {
      const r = this.threads[i].next();
      if (r.done) this.threads.splice(i, 1);
    }
    this._render();
    requestAnimationFrame(this._tick.bind(this));
  }
  _physicsStep(dt) {
    for (const sp of [...(this.sprites || []), ...(this.clones || [])]) {
      if (sp.physicsType === 'DYNAMIC') {
        sp.velocityX += sp.gravityX * dt;
        sp.velocityY += sp.gravityY * dt;
        sp.x += sp.velocityX * dt;
        sp.y += sp.velocityY * dt;
        sp.direction += sp.angularVelocity * dt;
        const halfH = this.stageH / 2;
        const b = this.spriteBounds(sp);
        if (b.bottom < -halfH) { sp.y += (-halfH - b.bottom); sp.velocityY *= -sp.bounce; }
      }
    }
  }
  _render() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.stageW, this.stageH);
    ctx.save();
    ctx.translate(this.stageW / 2, this.stageH / 2);
    ctx.scale(1, -1); // Catrobat y-up -> canvas y-down
    ctx.drawImage(this.penLayer, -this.stageW / 2, -this.stageH / 2);
    const drawList = [...this.sprites, ...this.clones].filter(s => s.visible).sort((a, b) => a.layer - b.layer);
    for (const sp of drawList) this._drawSprite(sp);
    ctx.restore();
    // text bubbles are drawn in screen space (not flipped)
    for (const sp of [...this.sprites, ...this.clones]) if (sp.text) this._drawText(sp);
  }
  _drawSprite(sp) {
    const ctx = this.ctx;
    const img = this._currentImage(sp);
    if (!img || !img.complete || !img.naturalWidth) return;
    const w = img.naturalWidth * sp.size / 100;
    const h = img.naturalHeight * sp.size / 100;
    ctx.save();
    ctx.translate(sp.x, sp.y);
    let rot = sp.direction;
    let flip = 1;
    if (sp.rotationStyle === 'leftRight') { flip = (Math.cos(deg2rad(rot)) < 0) ? -1 : 1; rot = 0; }
    else if (sp.rotationStyle === 'none') { rot = 0; }
    ctx.rotate(deg2rad(-(rot - 90))); // direction 0 = up
    ctx.scale(flip, 1);
    ctx.globalAlpha = Math.max(0, 1 - sp.transparency / 100);
    if (sp.brightness !== 100) ctx.filter = `brightness(${sp.brightness}%)`;
    ctx.drawImage(img, -w / 2, -h / 2, w, h);
    ctx.restore();
  }
  _drawText(sp) {
    const ctx = this.ctx;
    const rect = this.canvas.getBoundingClientRect();
    const scale = rect.width / this.stageW;
    const px = (sp.x + this.stageW / 2) * scale;
    const py = (this.stageH / 2 - sp.y) * scale;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.font = `${(sp.textSize || 20)}px sans-serif`;
    ctx.fillStyle = sp.textColor || '#000000';
    ctx.textAlign = sp.textAlign || 'left';
    ctx.fillText(sp.text, px * (this.canvas.width / rect.width), py * (this.canvas.height / rect.height));
    ctx.restore();
  }

  // --- sound -----------------------------------------------------------
  playSound(sp, name) {
    const s = sp.sounds.find(s => s.name === name);
    if (!s || !s.file) return;
    const template = this.audio.get(s.file);
    if (!template) return;
    const node = template.cloneNode();
    node.volume = (sp.volume ?? 100) / 100;
    node.play().catch(() => {});
    return node;
  }

  // --- script/brick interpreter ----------------------------------------
  *_runScript(sp, script) {
    yield* this._runBricks(sp, script.bricks);
  }

  *_runBricks(sp, bricks) {
    for (const b of bricks) {
      const r = yield* this._runBrick(sp, b);
      if (r === 'STOP_THREAD') return 'STOP_THREAD';
    }
  }

  *_runBrick(sp, b) {
    const ctx = { sprite: sp, engine: this };
    const F = (cat) => Formula.evaluate((b.formulas || {})[cat], ctx);
    const N = (cat) => Formula.toNumber(F(cat));

    switch (b.type) {
      // ---- control ----
      case 'NoteBrick': return;
      case 'WaitBrick': { let t = N('TIME_TO_WAIT_IN_SECONDS'); const end = performance.now() + t * 1000; while (performance.now() < end) yield; return; }
      case 'WaitUntilBrick': { while (!Formula.toBool(F('IF_CONDITION'))) yield; return; }
      case 'WaitTillIdleBrick': return; // no async media queue to wait on in this template
      case 'IfLogicBeginBrick': {
        if (Formula.toBool(F('IF_CONDITION'))) return yield* this._runBricks(sp, b.bricks || []);
        else return yield* this._runBricks(sp, b.elseBricks || []);
      }
      case 'IfThenLogicBeginBrick': {
        if (Formula.toBool(F('IF_CONDITION'))) return yield* this._runBricks(sp, b.bricks || []);
        return;
      }
      case 'ForeverBrick': { while (true) { const r = yield* this._runBricks(sp, b.bricks || []); if (r === 'STOP_THREAD') return r; yield; } }
      case 'RepeatBrick': { let n = Math.round(N('TIMES_TO_REPEAT')); for (let i = 0; i < n; i++) { const r = yield* this._runBricks(sp, b.bricks || []); if (r === 'STOP_THREAD') return r; yield; } return; }
      case 'RepeatUntilBrick': { while (!Formula.toBool(F('REPEAT_UNTIL_CONDITION'))) { const r = yield* this._runBricks(sp, b.bricks || []); if (r === 'STOP_THREAD') return r; yield; } return; }
      case 'ForVariableFromToBrick': {
        const from = N('FOR_LOOP_FROM'), to = N('FOR_LOOP_TO');
        const step = from <= to ? 1 : -1;
        for (let v = from; step > 0 ? v <= to : v >= to; v += step) {
          this.setVariable(sp, b.variable, v);
          const r = yield* this._runBricks(sp, b.bricks || []);
          if (r === 'STOP_THREAD') return r;
          yield;
        }
        return;
      }
      case 'ForItemInUserListBrick': {
        const list = this.getList(sp, b.list);
        for (const item of [...list]) {
          if (b.variable) this.setVariable(sp, b.variable, item);
          const r = yield* this._runBricks(sp, b.bricks || []);
          if (r === 'STOP_THREAD') return r;
          yield;
        }
        return;
      }
      case 'StopScriptBrick': return 'STOP_THREAD';
      case 'BroadcastBrick': this.broadcast(b.broadcastMessage); return;
      case 'BroadcastWaitBrick': {
        const started = this.broadcast(b.broadcastMessage);
        let pending = new Set(started);
        while (pending.size) {
          pending = new Set([...pending].filter(t => this.threads.includes(t)));
          if (pending.size) yield;
        }
        return;
      }
      case 'SceneStartBrick': this.loadScene(b.sceneToStart); return 'STOP_THREAD';
      case 'SceneTransitionBrick': this.loadScene(b.sceneForTransition); return 'STOP_THREAD';
      case 'ExitStageBrick': return 'STOP_THREAD';
      case 'CloneBrick': this._cloneSprite(sp); return;
      case 'DeleteThisCloneBrick': this._deleteClone(sp); return 'STOP_THREAD';
      case 'UserDefinedBrick': console.warn('[brick] custom "my block" definitions are not executed by this template'); return;

      // ---- motion ----
      case 'PlaceAtBrick': sp.x = N('X_POSITION'); sp.y = N('Y_POSITION'); return;
      case 'SetXBrick': sp.x = N('X_POSITION'); return;
      case 'SetYBrick': sp.y = N('Y_POSITION'); return;
      case 'ChangeXByNBrick': sp.x += N('X_POSITION_CHANGE'); return;
      case 'ChangeYByNBrick': sp.y += N('Y_POSITION_CHANGE'); return;
      case 'MoveNStepsBrick': { const n = N('STEPS'); sp.x += n * Math.sin(deg2rad(sp.direction)); sp.y += n * Math.cos(deg2rad(sp.direction)); return; }
      case 'TurnLeftBrick': sp.direction -= N('TURN_LEFT_DEGREES'); return;
      case 'TurnRightBrick': sp.direction += N('TURN_RIGHT_DEGREES'); return;
      case 'PointInDirectionBrick': sp.direction = N('DEGREES'); return;
      case 'PointToBrick': { const other = this._findSprite(b.sprite); if (other) sp.direction = rad2deg(Math.atan2(other.x - sp.x, other.y - sp.y)); return; }
      case 'GoToBrick': { const other = this._findSprite(b.spinnerSelection); if (other) { sp.x = other.x; sp.y = other.y; } return; }
      case 'GlideToBrick': {
        const x0 = sp.x, y0 = sp.y, x1 = N('X_DESTINATION'), y1 = N('Y_DESTINATION');
        const dur = Math.max(0, N('DURATION_IN_SECONDS')) * 1000;
        const start = performance.now();
        if (dur === 0) { sp.x = x1; sp.y = y1; return; }
        while (true) {
          const t = Math.min(1, (performance.now() - start) / dur);
          sp.x = x0 + (x1 - x0) * t; sp.y = y0 + (y1 - y0) * t;
          if (t >= 1) return;
          yield;
        }
      }
      case 'GoNStepsBackBrick': sp.layer -= Math.round(N('STEPS')); return;
      case 'ComeToFrontBrick': sp.layer = 1000 + (this._layerCounter = (this._layerCounter || 0) + 1); return;
      case 'IfOnEdgeBounceBrick': { if (this.isOnEdge(sp)) sp.direction = 180 - sp.direction; return; }
      case 'SetRotationStyleBrick': {
        sp.rotationStyle = { '0': 'normal', '1': 'leftRight', '2': 'none' }[b.selection] || 'normal'; return;
      }
      case 'GoThroughBrick': sp.x = N('X_DESTINATION'); sp.y = N('Y_DESTINATION'); return;
      case 'ArcBrick': return; // pen-arc drawing not implemented; no-op so scripts keep running
      case 'TapAtBrick': case 'TapForBrick': case 'TouchAndSlideBrick':
        console.warn('[brick] synthetic input simulation bricks are not implemented (' + b.type + ')'); return;

      // ---- physics ----
      case 'SetPhysicsObjectTypeBrick': sp.physicsType = b.type || 'NONE'; return;
      case 'SetMassBrick': sp.mass = N('PHYSICS_MASS'); return;
      case 'SetBounceBrick': sp.bounce = N('PHYSICS_BOUNCE_FACTOR'); return;
      case 'SetFrictionBrick': sp.friction = N('PHYSICS_FRICTION'); return;
      case 'SetGravityBrick': sp.gravityX = N('PHYSICS_GRAVITY_X'); sp.gravityY = N('PHYSICS_GRAVITY_Y'); return;
      case 'SetVelocityBrick': sp.velocityX = N('PHYSICS_VELOCITY_X'); sp.velocityY = N('PHYSICS_VELOCITY_Y'); return;
      case 'TurnLeftSpeedBrick': sp.angularVelocity = -N('PHYSICS_TURN_LEFT_SPEED'); return;
      case 'TurnRightSpeedBrick': sp.angularVelocity = N('PHYSICS_TURN_RIGHT_SPEED'); return;
      case 'VibrationBrick': if (navigator.vibrate) navigator.vibrate(N('VIBRATE_DURATION_IN_SECONDS') * 1000); return;

      // ---- looks ----
      case 'SetLookBrick': case 'SetBackgroundAndWaitBrick': { const i = sp.looks.findIndex(l => l.name === b.look); if (i >= 0) sp.lookIndex = i; return; }
      case 'SetLookByIndexBrick': case 'SetBackgroundByIndexBrick': { const i = Math.round(N('LOOK_INDEX') || N('BACKGROUND_INDEX')) - 1; if (sp.looks.length) sp.lookIndex = ((i % sp.looks.length) + sp.looks.length) % sp.looks.length; return; }
      case 'NextLookBrick': if (sp.looks.length) sp.lookIndex = (sp.lookIndex + 1) % sp.looks.length; return;
      case 'PreviousLookBrick': if (sp.looks.length) sp.lookIndex = (sp.lookIndex - 1 + sp.looks.length) % sp.looks.length; return;
      case 'LookRequestBrick': return; // network look loading not implemented
      case 'SetSizeToBrick': sp.size = N('SIZE'); return;
      case 'ChangeSizeByNBrick': sp.size += N('SIZE_CHANGE'); return;
      case 'SetTransparencyBrick': sp.transparency = N('TRANSPARENCY'); return;
      case 'ChangeTransparencyByNBrick': sp.transparency += N('TRANSPARENCY_CHANGE'); return;
      case 'SetBrightnessBrick': sp.brightness = N('BRIGHTNESS'); return;
      case 'ChangeBrightnessByNBrick': sp.brightness += N('BRIGHTNESS_CHANGE'); return;
      case 'SetColorBrick': sp.colorFilter = String(F('COLOR')); return;
      case 'ChangeColorByNBrick': return; // colour-shift filter not implemented
      case 'ShowBrick': sp.visible = true; return;
      case 'HideBrick': sp.visible = false; return;
      case 'ShowTextBrick': sp.text = String(this.getVariable(sp, b.userVariable)); sp.textX = N('X_POSITION'); sp.textY = N('Y_POSITION'); return;
      case 'ShowTextColorSizeAlignmentBrick': {
        sp.text = String(this.getVariable(sp, b.userVariable));
        sp.textX = N('X_POSITION'); sp.textY = N('Y_POSITION'); sp.textSize = N('SIZE');
        sp.textColor = String(F('COLOR'));
        sp.textAlign = { '0': 'left', '1': 'center', '2': 'right' }[b.alignmentSelection] || 'left';
        return;
      }
      case 'HideTextBrick': sp.text = null; return;

      // ---- pen ----
      case 'PenDownBrick': sp.penDown = true; return;
      case 'PenUpBrick': sp.penDown = false; return;
      case 'SetPenSizeBrick': sp.penSize = N('PEN_SIZE'); return;
      case 'SetPenColorBrick': {
        const r = Math.round(N('PEN_COLOR_RED')), g = Math.round(N('PEN_COLOR_GREEN')), bl = Math.round(N('PEN_COLOR_BLUE'));
        sp.penColor = `rgb(${r},${g},${bl})`; return;
      }
      case 'StampBrick': this._stamp(sp); return;
      case 'ClearBackgroundBrick': this.penCtx.clearRect(0, 0, this.stageW, this.stageH); return;

      // ---- sound ----
      case 'PlaySoundBrick': this.playSound(sp, b.sound); return;
      case 'PlaySoundAndWaitBrick': { const node = this.playSound(sp, b.sound); if (!node) return; let done = false; node.addEventListener('ended', () => done = true); while (!done) yield; return; }
      case 'PlaySoundAtBrick': this.playSound(sp, b.sound); return; // start-offset seeking not implemented
      case 'StopSoundBrick': return; // per-sound stop not tracked; use StopAllSoundsBrick
      case 'StopAllSoundsBrick': for (const a of this.audio.values()) { a.pause(); a.currentTime = 0; } return;
      case 'SetVolumeToBrick': sp.volume = N('VOLUME'); return;
      case 'ChangeVolumeByNBrick': sp.volume = (sp.volume ?? 100) + N('VOLUME_CHANGE'); return;

      // ---- variables / lists ----
      case 'SetVariableBrick': this.setVariable(sp, b.variable, F('VARIABLE')); return;
      case 'ChangeVariableBrick': this.setVariable(sp, b.variable, Formula.toNumber(this.getVariable(sp, b.variable)) + N('VARIABLE_CHANGE')); return;
      case 'AddItemToUserListBrick': this.getList(sp, b.list).push(F('LIST_ADD_ITEM')); return;
      case 'DeleteItemOfUserListBrick': { const i = Math.round(N('LIST_DELETE_ITEM')) - 1; const list = this.getList(sp, b.list); if (i >= 0 && i < list.length) list.splice(i, 1); return; }
      case 'ClearUserListBrick': this.getList(sp, b.list).length = 0; return;
      case 'InsertItemIntoUserListBrick': { const i = Math.round(N('INSERT_ITEM_INTO_USERLIST_INDEX')) - 1; const list = this.getList(sp, b.list); list.splice(Math.max(0, Math.min(list.length, i)), 0, F('INSERT_ITEM_INTO_USERLIST_VALUE')); return; }
      case 'ReplaceItemInUserListBrick': { const i = Math.round(N('REPLACE_ITEM_IN_USERLIST_INDEX')) - 1; const list = this.getList(sp, b.list); if (i >= 0 && i < list.length) list[i] = F('REPLACE_ITEM_IN_USERLIST_VALUE'); return; }

      // ---- device storage (localStorage-backed; real files need a native bridge) ----
      case 'WriteVariableOnDeviceBrick': try { localStorage.setItem('ncv:' + b.userVariable, JSON.stringify(this.getVariable(sp, b.userVariable))); } catch (e) {} return;
      case 'ReadVariableFromDeviceBrick': try { const raw = localStorage.getItem('ncv:' + b.userVariable); if (raw !== null) this.setVariable(sp, b.userVariable, JSON.parse(raw)); } catch (e) {} return;
      case 'WriteVariableToFileBrick': try { localStorage.setItem('ncf:' + F('WRITE_FILENAME'), JSON.stringify(this.getVariable(sp, b.variable))); } catch (e) {} return;
      case 'ReadVariableFromFileBrick': try { const raw = localStorage.getItem('ncf:' + F('READ_FILENAME')); if (raw !== null) this.setVariable(sp, b.variable, JSON.parse(raw)); } catch (e) {} return;
      case 'WriteListOnDeviceBrick': try { localStorage.setItem('ncl:' + b.list, JSON.stringify(this.getList(sp, b.list))); } catch (e) {} return;
      case 'ReadListFromDeviceBrick': try { const raw = localStorage.getItem('ncl:' + b.list); if (raw !== null) { const list = this.getList(sp, b.list); list.length = 0; list.push(...JSON.parse(raw)); } } catch (e) {} return;
      case 'StoreCSVIntoUserListBrick': {
        const csv = String(F('STORE_CSV_INTO_USERLIST_CSV'));
        const col = Math.round(N('STORE_CSV_INTO_USERLIST_COLUMN'));
        const list = this.getList(sp, b.list); list.length = 0;
        for (const line of csv.split(/\r?\n/)) { if (!line) continue; const cells = line.split(','); list.push(cells[col - 1] ?? ''); }
        return;
      }
      case 'WebRequestBrick': {
        const url = String(F('WEB_REQUEST'));
        let done = false, result = '';
        fetch(url).then(r => r.text()).then(t => { result = t; done = true; }).catch(() => { done = true; });
        while (!done) yield;
        this.setVariable(sp, b.userVariable, result);
        return;
      }

      default:
        console.warn('[brick] unimplemented', b.type);
        return;
    }
  }

  _findSprite(nameOrSelector) {
    const all = [...this.sprites, ...this.clones];
    return all.find(s => s.name === nameOrSelector);
  }
  _stamp(sp) {
    const img = this._currentImage(sp);
    if (!img) return;
    const w = img.naturalWidth * sp.size / 100, h = img.naturalHeight * sp.size / 100;
    this.penCtx.save();
    this.penCtx.translate(this.stageW / 2 + sp.x, this.stageH / 2 - sp.y);
    this.penCtx.rotate(-deg2rad(sp.direction - 90) * -1);
    this.penCtx.drawImage(img, -w / 2, -h / 2, w, h);
    this.penCtx.restore();
  }
  _cloneSprite(sp) {
    const clone = JSON.parse(JSON.stringify({
      name: sp.name, x: sp.x, y: sp.y, direction: sp.direction, size: sp.size,
      transparency: sp.transparency, brightness: sp.brightness, lookIndex: sp.lookIndex,
      rotationStyle: sp.rotationStyle, variables: sp.variables, lists: sp.lists,
      layer: sp.layer, visible: sp.visible,
    }));
    clone.def = sp.def; clone.looks = sp.def.looks; clone.sounds = sp.def.sounds;
    clone.isClone = true; clone.penDown = false; clone.physicsType = sp.physicsType;
    clone.velocityX = 0; clone.velocityY = 0; clone.angularVelocity = 0;
    clone.mass = sp.mass; clone.bounce = sp.bounce; clone.friction = sp.friction;
    clone.gravityX = sp.gravityX; clone.gravityY = sp.gravityY;
    this.clones.push(clone);
    this._startScriptsOfType(clone, ['WhenClonedScript']);
  }
  _deleteClone(sp) {
    const i = this.clones.indexOf(sp);
    if (i >= 0) this.clones.splice(i, 1);
    this.threads = this.threads.filter(t => t.owner !== sp);
  }
}

window.NewcatroidEngine = Engine;
})();
