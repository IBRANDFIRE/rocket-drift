# NEWCATROID Runner — generic Catrobat/Pocket Code APK template

A reusable Android app skeleton that runs `.catrobat` projects inside a
WebView, using a JS engine (`runtime.js`) that interprets the project's
bricks directly — no Catrobat/Pocket Code app install required on the
target device. Swap the bundled project and you get a different game APK
from the same template.

## What's in here

```
tools/parse_project.py   <- converts a .catrobat file into assets/project/
app/src/main/assets/
  index.html              <- host page, boots the engine
  runtime.js              <- the engine: brick interpreter + formula evaluator
  project/project.json    <- your game, converted (regenerate this to swap games)
  project/media/          <- your game's images & sounds
app/src/main/java/...     <- MainActivity.java (fullscreen WebView host)
app/src/main/AndroidManifest.xml
app/build.gradle, build.gradle, settings.gradle, gradle.properties
```

## 1. Swapping in a different game

```
python3 tools/parse_project.py path/to/your_game.catrobat app/src/main/assets/project
```

This **overwrites** `app/src/main/assets/project/`. Requires Python 3 with
`lxml` (`pip install lxml --break-system-packages` if you don't have it).
Nothing else in the template needs to change — same engine, new project.

Rename `applicationId` in `app/build.gradle` and `app_name` in
`res/values/strings.xml` per game if you're shipping more than one APK
from this template so they don't collide on a device.

## 2. Building the APK

**Option A — Android Studio (most reliable):** Open the `template/` folder
as a project. Studio will generate the Gradle wrapper automatically the
first time it syncs. Build → Build APK(s).

**Option B — command line with a system-installed Gradle:**
```
gradle assembleDebug
```
The unsigned/debug APK lands in `app/build/outputs/apk/debug/`.
(This repo doesn't ship `gradlew`/the wrapper jar, since that's a binary
file — either let Android Studio generate it, or use a Gradle you already
have installed.)

**CxxDroid / AndroLuaX:** this is a standard Gradle-based Android project
(WebView host + assets), not a raw single-file `.java` build, so CxxDroid's
built-in Java compiler alone won't produce this APK. You'll need Gradle
available in your build environment (e.g. Termux with Gradle installed) or
Android Studio on a desktop. Once built, the resulting `.apk` installs and
runs on any Android 5.0+ (API 21+) device — including via CxxDroid's
installer — same as any other APK.

## 3. Known limitations (things simplified or stubbed)

The engine covers the full common brick set (motion, looks, sound, pen,
variables/lists, control flow, broadcasts, cloning, basic physics). A few
things are intentionally out of scope for this template:

- **Custom "my blocks"** (`UserDefinedBrick`) are logged to the console but
  not executed — the definition-resolution logic wasn't built out.
- **Per-pixel color collision** (`COLLIDES_WITH_COLOR`, `COLOR_TOUCHES_COLOR`)
  always returns false — collision detection is bounding-box only.
- **Device storage bricks** (`Read/WriteVariableOnDevice`,
  `Read/WriteVariableToFile`, `Read/WriteListOnDevice`) use the WebView's
  `localStorage`, not real device files.
- **`WhenConditionScript`, `WhenBackgroundChangesScript`, `WhenBounceOffScript`**
  triggers are parsed but never started — their bricks won't run.
- **`GoToBrick`'s "random position" / "touch position" targeting** isn't
  resolved — it only works when pointed at another sprite by name.
- **Physics** is a simplified velocity/gravity/bounce model, not a real
  physics engine (no rotation-aware collision response between bodies).
- **`ArcBrick`, `TapAtBrick`/`TapForBrick`/`TouchAndSlideBrick`** (synthetic
  input playback) are no-ops.

None of these throw — a project using them keeps running, just without
that specific behavior. Check the browser/WebView JS console
(`chrome://inspect` on a connected device) to see exactly which bricks a
given project hits that aren't implemented, then extend the `switch` in
`runtime.js`'s `_runBrick()` — every case follows the same pattern.

## 4. How the interpreter works, briefly

`parse_project.py` resolves Catrobat's XStream-style `reference="../.."`
pointers (used for shared variables/lists) and flattens `code.xml` into
plain JSON — nested if/else and loop bodies included. `runtime.js` compiles
each script into a JS generator function; one `yield` = one scheduler tick,
so `Wait`, `RepeatUntil`, and infinite loops cooperate with the render loop
instead of blocking it. `Formula.evaluate()` walks the same nested-formula
JSON that the XML formula trees became, dispatching on `OPERATOR` /
`FUNCTION` / `SENSOR` / `USER_VARIABLE` / `USER_LIST` / `COLLISION_FORMULA`.
